<?php
include "db.php";
session_start();

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    $result = mysqli_query(
        $conn,
        "SELECT * FROM users WHERE email='$email' LIMIT 1"
    );

    if (mysqli_num_rows($result) == 1) {

        $user = mysqli_fetch_assoc($result);

        if (password_verify($password, $user['password'])) {

            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];

            header("Location: index.php");
            exit;

        } else {
            $message = "Wrong password.";
        }

    } else {
        $message = "Account not found.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Login - FoodExpress</title>

<link rel="stylesheet"
href="css/style.css">

<style>

.auth-section {
    min-height:70vh;
    display:flex;
    justify-content:center;
    align-items:center;
    padding:50px 20px;
}

.auth-box {
    width:100%;
    max-width:430px;
    background:white;
    padding:35px;
    border-radius:16px;
    box-shadow:0 8px 30px rgba(0,0,0,0.10);
}

.auth-logo {
    text-align:center;
    color:#e63946;
    font-size:28px;
    font-weight:bold;
    margin-bottom:8px;
}

.auth-title {
    text-align:center;
    margin-bottom:8px;
    font-size:27px;
}

.auth-subtitle {
    text-align:center;
    color:#777;
    margin-bottom:25px;
}

.auth-box label {
    display:block;
    font-weight:bold;
    margin-top:15px;
    margin-bottom:7px;
}

.auth-box input {
    width:100%;
    padding:13px;
    border:1px solid #ddd;
    border-radius:8px;
    box-sizing:border-box;
    font-size:15px;
    outline:none;
}

.auth-box input:focus {
    border-color:#e63946;
}

.auth-button {
    width:100%;
    padding:13px;
    margin-top:22px;
    border:none;
    border-radius:8px;
    background:#e63946;
    color:white;
    font-size:16px;
    font-weight:bold;
    cursor:pointer;
}

.auth-button:hover {
    background:#c92f3b;
}

.message {
    background:#ffe5e5;
    color:#c62828;
    padding:11px;
    border-radius:7px;
    text-align:center;
    margin-bottom:15px;
}

.register-text {
    text-align:center;
    margin-top:20px;
    color:#666;
}

.register-text a {
    color:#e63946;
    font-weight:bold;
    text-decoration:none;
}

</style>

</head>

<body>

<!-- NAVBAR -->

<nav class="navbar">

<div class="logo">
FoodExpress
</div>

<div class="nav-links">

<a href="index.php">
Home
</a>

<a href="login.php">
Login
</a>

<a href="register.php">
Register
</a>

<a href="cart.php">
Cart
</a>

</div>

</nav>


<!-- LOGIN -->

<section class="auth-section">

<div class="auth-box">

<div class="auth-logo">
FoodExpress
</div>

<h2 class="auth-title">
Welcome Back
</h2>

<p class="auth-subtitle">
Login to continue ordering delicious food.
</p>


<?php if ($message != "") { ?>

<p class="message">
<?php echo htmlspecialchars($message); ?>
</p>

<?php } ?>


<form method="POST">

<label>
Email
</label>

<input
type="email"
name="email"
placeholder="Enter your email"
required
>


<label>
Password
</label>

<input
type="password"
name="password"
placeholder="Enter your password"
required
>


<button
type="submit"
class="auth-button"
>
Login
</button>

</form>


<p class="register-text">

Don't have an account?

<a href="register.php">
Register Now
</a>

</p>

</div>

</section>


<footer>

<p>
© 2026 FoodExpress |
Online Food Ordering System
</p>

</footer>

</body>

</html>